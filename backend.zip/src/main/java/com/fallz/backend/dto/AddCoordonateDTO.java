package com.fallz.backend.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class AddCoordonateDTO {

	private double latitude;

	private double longitude;
}
